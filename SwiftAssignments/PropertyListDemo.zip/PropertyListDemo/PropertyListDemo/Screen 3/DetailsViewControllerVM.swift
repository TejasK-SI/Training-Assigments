//
//  DetailsViewControllerVM.swift
//  PropertyListDemo
//
//  Created by Instructor on 17/08/23.
//

import Foundation

class DetailsViewControllerVM {
    var name        : String    = ""
    var email       : String    = ""
    var phone       : String    = ""
    var age         : String    = ""
    var eventDate   : Date      = Date.now
    var food        : Int       = 1
    var ambience    : Int       = 1
    var service     : Int       = 1
    
}
